require 'rails_helper'

RSpec.describe SiteController, type: :controller do

end
