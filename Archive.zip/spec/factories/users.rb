FactoryGirl.define do
  factory :user do
    u_id 1
    name "MyString"
    stride_length_walking "MyString"
    stride_length_running "MyString"
    timezone "MyString"
    photo "MyString"
    city "MyString"
    country "MyString"
  end
end
